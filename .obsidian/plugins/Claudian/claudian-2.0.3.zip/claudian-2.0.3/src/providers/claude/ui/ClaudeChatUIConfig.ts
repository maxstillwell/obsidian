import { getRuntimeEnvironmentVariables } from '../../../core/providers/providerEnvironment';
import type {
  ProviderChatUIConfig,
  ProviderIconSvg,
  ProviderPermissionModeToggleConfig,
  ProviderReasoningOption,
  ProviderUIOption,
} from '../../../core/providers/types';
import { getCustomModelIds, getModelsFromEnvironment } from '../env/claudeModelEnv';
import { getClaudeProviderSettings, updateClaudeProviderSettings } from '../settings';
import {
  type ClaudeModel,
  DEFAULT_CLAUDE_MODELS,
  DEFAULT_EFFORT_LEVEL,
  DEFAULT_THINKING_BUDGET,
  EFFORT_LEVELS,
  filterVisibleModelOptions,
  getContextWindowSize,
  isAdaptiveThinkingModel,
  normalizeVisibleModelVariant,
  THINKING_BUDGETS,
} from '../types/models';

const CLAUDE_ICON: ProviderIconSvg = {
  viewBox: '0 -.01 39.5 39.53',
  path: 'm7.75 26.27 7.77-4.36.13-.38-.13-.21h-.38l-1.3-.08-4.44-.12-3.85-.16-3.73-.2-.94-.2-.88-1.16.09-.58.79-.53 1.13.1 2.5.17 3.75.26 2.72.16 4.03.42h.64l.09-.26-.22-.16-.17-.16-3.88-2.63-4.2-2.78-2.2-1.6-1.19-.81-.6-.76-.26-1.66 1.08-1.19 1.45.1.37.1 1.47 1.13 3.14 2.43 4.1 3.02.6.5.24-.17.03-.12-.27-.45-2.23-4.03-2.38-4.1-1.06-1.7-.28-1.02c-.1-.42-.17-.77-.17-1.2l1.23-1.67.68-.22 1.64.22.69.6 1.02 2.33 1.65 3.67 2.56 4.99.75 1.48.4 1.37.15.42h.26v-.24l.21-2.81.39-3.45.38-4.44.13-1.25.62-1.5 1.23-.81.96.46.79 1.13-.11.73-.47 3.05-.92 4.78-.6 3.2h.35l.4-.4 1.62-2.15 2.72-3.4 1.2-1.35 1.4-1.49.9-.71h1.7l1.25 1.86-.56 1.92-1.75 2.22-1.45 1.88-2.08 2.8-1.3 2.24.12.18.31-.03 4.7-1 2.54-.46 3.03-.52 1.37.64.15.65-.54 1.33-3.24.8-3.8.76-5.66 1.34-.07.05.08.1 2.55.24 1.09.06h2.67l4.97.37 1.3.86.78 1.05-.13.8-2 1.02-2.7-.64-6.3-1.5-2.16-.54h-.3v.18l1.8 1.76 3.3 2.98 4.13 3.84.21.95-.53.75-.56-.08-3.63-2.73-1.4-1.23-3.17-2.67h-.21v.28l.73 1.07 3.86 5.8.2 1.78-.28.58-1 .35-1.1-.2-2.26-3.17-2.33-3.57-1.88-3.2-.23.13-1.11 11.95-.52.61-1.2.46-1-.76-.53-1.23.53-2.43.64-3.17.52-2.52.47-3.13.28-1.04-.02-.07-.23.03-2.36 3.24-3.59 4.85-2.84 3.04-.68.27-1.18-.61.11-1.09.66-.97 3.93-5 2.37-3.1 1.53-1.79-.01-.26h-.09l-10.44 6.78-1.86.24-.8-.75.1-1.23.38-.4 3.14-2.16z',
};

const CLAUDE_PERMISSION_MODE_TOGGLE: ProviderPermissionModeToggleConfig = {
  inactiveValue: 'normal',
  inactiveLabel: 'Safe',
  activeValue: 'yolo',
  activeLabel: 'YOLO',
  planValue: 'plan',
  planLabel: 'PLAN',
};

export const claudeChatUIConfig: ProviderChatUIConfig = {
  getModelOptions(settings) {
    const customModels = getModelsFromEnvironment(
      getRuntimeEnvironmentVariables(settings, 'claude'),
    );
    if (customModels.length > 0) {
      return customModels;
    }

    const models = [...DEFAULT_CLAUDE_MODELS];
    const claudeSettings = getClaudeProviderSettings(settings);
    return filterVisibleModelOptions(
      models,
      claudeSettings.enableOpus1M,
      claudeSettings.enableSonnet1M,
    );
  },

  ownsModel(model: string, settings: Record<string, unknown>): boolean {
    return this.getModelOptions(settings).some((option: ProviderUIOption) => option.value === model);
  },

  isAdaptiveReasoningModel(model: string): boolean {
    return isAdaptiveThinkingModel(model);
  },

  getReasoningOptions(model: string): ProviderReasoningOption[] {
    if (isAdaptiveThinkingModel(model)) {
      return EFFORT_LEVELS.map(e => ({ value: e.value, label: e.label }));
    }
    return THINKING_BUDGETS.map(b => ({ value: b.value, label: b.label, tokens: b.tokens }));
  },

  getDefaultReasoningValue(model: string): string {
    if (isAdaptiveThinkingModel(model)) {
      return DEFAULT_EFFORT_LEVEL[model] ?? 'high';
    }
    return DEFAULT_THINKING_BUDGET[model] ?? 'off';
  },

  getContextWindowSize(model: string, customLimits?: Record<string, number>): number {
    return getContextWindowSize(model, customLimits);
  },

  isDefaultModel(model: string): boolean {
    return DEFAULT_CLAUDE_MODELS.some(m => m.value === model);
  },

  applyModelDefaults(model: string, settings: unknown): void {
    if (DEFAULT_CLAUDE_MODELS.some(m => m.value === model)) {
      const target = settings as Record<string, unknown>;
      target.thinkingBudget = DEFAULT_THINKING_BUDGET[model as ClaudeModel];
      if (isAdaptiveThinkingModel(model)) {
        target.effortLevel = DEFAULT_EFFORT_LEVEL[model as ClaudeModel] ?? 'high';
      }
      updateClaudeProviderSettings(target, { lastModel: model });
    } else {
      (settings as Record<string, unknown>).lastCustomModel = model;
    }
  },

  normalizeModelVariant(model: string, settings) {
    const claudeSettings = getClaudeProviderSettings(settings);
    return normalizeVisibleModelVariant(
      model,
      claudeSettings.enableOpus1M,
      claudeSettings.enableSonnet1M,
    );
  },

  getCustomModelIds(envVars: Record<string, string>): Set<string> {
    return getCustomModelIds(envVars);
  },

  getPermissionModeToggle() {
    return CLAUDE_PERMISSION_MODE_TOGGLE;
  },

  isBangBashEnabled(settings) {
    return getClaudeProviderSettings(settings).enableBangBash;
  },

  getProviderIcon() {
    return CLAUDE_ICON;
  },
};

/** Re-export for type-only use in provider registration. */
export type { ProviderUIOption };
